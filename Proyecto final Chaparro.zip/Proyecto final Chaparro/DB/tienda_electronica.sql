-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-11-2024 a las 10:59:21
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda_electronica`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_ordenes`
--

CREATE TABLE `detalles_ordenes` (
  `id` int(11) NOT NULL,
  `orden_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalles_ordenes`
--

INSERT INTO `detalles_ordenes` (`id`, `orden_id`, `producto_id`, `cantidad`, `precio`) VALUES
(1, 1, 22, 1, 9500000.00),
(2, 1, 23, 2, 8000000.00),
(3, 2, 23, 1, 8000000.00),
(4, 2, 24, 1, 2500000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ordenes`
--

CREATE TABLE `ordenes` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `estado` enum('pendiente','completada','cancelada') DEFAULT 'pendiente',
  `monto_total` decimal(10,2) NOT NULL,
  `actualizado_en` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ordenes`
--

INSERT INTO `ordenes` (`id`, `usuario_id`, `estado`, `monto_total`, `actualizado_en`) VALUES
(1, 2, 'pendiente', 25500000.00, '2024-11-19 03:25:25'),
(2, 2, 'pendiente', 10500000.00, '2024-11-19 03:27:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `ubicacion_imagen` varchar(255) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `precio`, `stock`, `ubicacion_imagen`, `categoria`) VALUES
(21, 'Dell XPS 13', 'Laptop de alta gama con procesador Intel Core i7, 16GB RAM, 512GB SSD', 7000000.00, 10, 'Imagenes\\Dell XPS 13.jpg', 'gama alta'),
(22, 'MacBook Pro 16', 'Laptop de alta gama con procesador Apple M1 Pro, 16GB RAM, 1TB SSD', 9500000.00, 8, 'Imagenes\\MacBook Pro 16.jpg', 'gama alta'),
(23, 'HP Spectre x360', 'Laptop de alta gama con procesador Intel Core i7, 16GB RAM, 1TB SSD', 8000000.00, 15, 'Imagenes\\HP Spectre x360.jpg', 'gama alta'),
(24, 'Acer Aspire 5', 'Laptop de baja gama con procesador Intel Core i3, 8GB RAM, 256GB SSD', 2500000.00, 20, 'Imagenes\\Acer Aspire 5.jpg', 'gama baja'),
(25, 'Lenovo IdeaPad 3', 'Laptop de baja gama con procesador AMD Ryzen 3, 8GB RAM, 256GB SSD', 2300000.00, 25, 'Imagenes\\Lenovo IdeaPad 3.jpg', 'gama baja'),
(26, 'ASUS VivoBook 15', 'Laptop de baja gama con procesador Intel Pentium, 4GB RAM, 128GB SSD', 2000000.00, 30, 'Imagenes\\ASUS VivoBook 15.jpg', 'gama baja'),
(27, 'Microsoft Surface Laptop 4', 'Laptop destacada con procesador Intel Core i5, 8GB RAM, 256GB SSD', 4500000.00, 12, 'Imagenes\\Microsoft Surface Laptop 4.jpg', 'destacados'),
(28, 'Razer Blade 15', 'Laptop destacada con procesador Intel Core i7, 16GB RAM, 512GB SSD', 9000000.00, 10, 'Imagenes\\Razer Blade 15.jpg', 'destacados'),
(29, 'Dell Inspiron 14', 'Laptop destacada con procesador Intel Core i5, 8GB RAM, 512GB SSD', 3500000.00, 9, 'Imagenes\\Dell Inspiron 14.jpg', 'destacados'),
(30, 'Apple MacBook Air', 'Laptop de alta gama con procesador Apple M1, 8GB RAM, 256GB SSD', 6000000.00, 7, 'Imagenes\\Apple MacBook Air.jpg', 'gama alta'),
(31, 'HP Envy 13', 'Laptop de alta gama con procesador Intel Core i5, 8GB RAM, 512GB SSD', 5500000.00, 5, 'Imagenes\\HP Envy 13.jpg', 'gama alta'),
(32, 'Acer Chromebook 314', 'Laptop de baja gama con procesador Intel Celeron, 4GB RAM, 64GB eMMC', 1500000.00, 22, 'Imagenes\\Acer Chromebook 314 .jpg', 'gama baja'),
(33, 'Lenovo Chromebook Flex 5', 'Laptop de baja gama con procesador Intel Core i3, 4GB RAM, 64GB eMMC', 1800000.00, 18, 'Imagenes\\Lenovo Chromebook Flex 5.jpg', 'gama baja'),
(34, 'ASUS ZenBook 14', 'Laptop destacada con procesador AMD Ryzen 5, 8GB RAM, 512GB SSD', 4000000.00, 11, 'Imagenes\\ASUS ZenBook 14.jpg', 'destacados'),
(35, 'MSI GF63 Thin', 'Laptop destacada con procesador Intel Core i7, 16GB RAM, 512GB SSD, NVIDIA GTX 1650', 7500000.00, 14, 'Imagenes\\MSI GF63 Thin.jpg', 'destacados');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones`
--

CREATE TABLE `sesiones` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `nombre_completo` varchar(100) NOT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `rol` enum('cliente','administrador') DEFAULT 'cliente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_usuario`, `correo`, `contrasena`, `nombre_completo`, `telefono`, `direccion`, `rol`) VALUES
(1, 'admin', 'admin@ejemplo.com', 'admin123', 'Usuario Administrador', NULL, NULL, 'administrador'),
(2, 'usuario_prueba', 'prueba@ejemplo.com', 'prueba123', 'Usuario de Prueba', NULL, NULL, 'cliente'),
(6, 'Juanes', 'juan@prueba.com', 'prueba123', 'Juan Esteban Torres', '3112224455', 'Bogota', 'administrador'),
(7, 'Luis', 'luis@prueba.com', 'prueba123', 'Luis Fernando Pineda', '3124558796', 'Caqueza', 'cliente');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `detalles_ordenes`
--
ALTER TABLE `detalles_ordenes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orden_id` (`orden_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `sesiones`
--
ALTER TABLE `sesiones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre_usuario` (`nombre_usuario`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalles_ordenes`
--
ALTER TABLE `detalles_ordenes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT de la tabla `sesiones`
--
ALTER TABLE `sesiones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalles_ordenes`
--
ALTER TABLE `detalles_ordenes`
  ADD CONSTRAINT `detalles_ordenes_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `detalles_ordenes_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `ordenes`
--
ALTER TABLE `ordenes`
  ADD CONSTRAINT `ordenes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `sesiones`
--
ALTER TABLE `sesiones`
  ADD CONSTRAINT `sesiones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
